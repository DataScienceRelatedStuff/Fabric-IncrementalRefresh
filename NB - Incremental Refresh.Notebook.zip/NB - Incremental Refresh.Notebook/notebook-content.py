# Fabric notebook source

# METADATA ********************

# META {
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "594de742-dd8f-47ac-add3-0c350a9c38f0",
# META       "default_lakehouse_name": "LH_IncrementalRefresh",
# META       "default_lakehouse_workspace_id": "9a569038-e1ec-4924-bede-318939b87546"
# META     }
# META   }
# META }

# CELL ********************

# Welcome to your new notebook
# Type here in the cell editor to add code!
%pip install semantic-link


# CELL ********************

import sempy.fabric as fabric
help(fabric.refresh_dataset)

# CELL ********************

import sempy.fabric as fabric
from datetime import datetime

workspacename = "20240526 - Incremental Refresh Custom or Weekly Partitions"
fabric.refresh_dataset("DatasetName", workspacename, refresh_type="full", commit_mode="transactional", apply_refresh_policy=True, effective_date=datetime(2023,12,4))

# CELL ********************

# Custom sized partitions
import datetime as dt
from datetime import date
import math
import sempy.fabric as fabric
currentdate = date.today()
referencedate = date(2023,1,1)
daysbetween = currentdate - referencedate
partitionsizeindays = 7
periodnumber = math.floor(daysbetween.days/partitionsizeindays)
effdate = referencedate + dt.timedelta(days=periodnumber)
#fabric.refresh_dataset("CustomPartitionsDemo", "IR Testing", refresh_type="full", commit_mode="transactional", apply_refresh_policy=True, effective_date=effdate)
effdate

# CELL ********************

# Half Month Partitions
import pandas as pd
import datetime as dt
from datetime import date
import sempy.fabric as fabric
currentdate = date.today()
referencedate = date(2023,1,1)
monthsbetween = (currentdate.year*12 + currentdate.month) - (referencedate.year*12 + referencedate.month)
is2ndhalfofmonth = int(currentdate.day >= 16)
periodnumber = monthsbetween * 2 + is2ndhalfofmonth
effdate = referencedate + dt.timedelta(days=periodnumber)
#fabric.refresh_dataset("CustomPartitionsDemo", "IR Testing", refresh_type="full", commit_mode="transactional", apply_refresh_policy=True, effective_date=effdate)
effdate

# CELL ********************

# Table of fiscal periods
import pandas as pd
import datetime as dt
from datetime import date
import sempy.fabric as fabric
data = {
     'FiscalPeriod': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24],
     'Start': [date(2023, 1, 1), date(2023, 1, 29), date(2023, 2, 26), date(2023, 4, 2), date(2023, 4, 30), date(2023, 5, 28), date(2023, 7, 2), date(2023, 7, 30), date(2023, 8, 27), date(2023, 10, 1), date(2023, 10, 29), date(2023, 11, 26), date(2023, 12, 31), date(2024, 1, 28), date(2024, 2, 25), date(2024, 3, 31), date(2024, 4, 28), date(2024, 5, 26), date(2024, 6, 30), date(2024, 7, 28), date(2024, 8, 25), date(2024, 9, 29), date(2024, 10, 27), date(2024, 12, 1)],
     'End': [date(2023, 1, 28), date(2023, 2, 25), date(2023, 4, 1), date(2023, 4, 29), date(2023, 5, 27), date(2023, 7, 1), date(2023, 7, 29), date(2023, 8, 26), date(2023, 9, 30), date(2023, 10, 28), date(2023, 11, 25), date(2023, 12, 30), date(2024, 1, 27), date(2024, 2, 24), date(2024, 3, 30), date(2024, 4, 27), date(2024, 5, 25), date(2024, 6, 29), date(2024, 7, 27), date(2024, 8, 24), date(2024, 9, 28), date(2024, 10, 26), date(2024, 11, 30), date(2025, 1, 4)]
}
df = pd.DataFrame(data)
currentdate = date.today()
referencedate = date(2023,1,1)
todayrow = df[(df['Start'] <= currentdate) & (df['End'] >= currentdate)]
thisperiod = todayrow['FiscalPeriod'].iloc[0]-1
effdate = referencedate + dt.timedelta(days=int(thisperiod))
#fabric.refresh_dataset("CustomPartitionsDemo", "IR Testing", refresh_type="full", commit_mode="transactional", apply_refresh_policy=True, effective_date=effdate)
effdate
